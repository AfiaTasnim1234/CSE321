#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
int seshtrm;
int count;
int *n;
int idx[1000];
void *fibonacciSeqThread(void *arg)
{
    n = (int *)malloc((seshtrm + 1) * sizeof(int));
    n[0] = 0;
    if (seshtrm != 0)
    {
        n[1] = 1;
    }
    for (int i = 2; i <= seshtrm; i++)
    {
        n[i] = n[i - 1] + n[i - 2];
    }
    return NULL;
}
void *searchingidxThread(void *arg)
{
    for (int j = 0; j < count; j++)
    {
        if (idx[j] < 0 || idx[j] > seshtrm)
        {
            printf("result of search #%d = -1\n", j + 1);
        }
        else
        {
            printf("result of search #%d = %d\n", j + 1, n[idx[j]]);
        }
    }
    return NULL;
}
int main()
{
    pthread_t fibonacciThread;
    pthread_t findingfiboThread;
    printf("Enter the term of Fibonacci sequence: \n");
    scanf("%d", &seshtrm);
    printf("How many numbers you are willing to search?: \n");
    scanf("%d", &count);
    for (int j = 0; j < count; j++)
    {
        printf("Enter search %d: \n", j + 1);
        scanf("%d", &idx[j]);
    }
    pthread_create(&fibonacciThread, NULL, fibonacciSeqThread, NULL);
    pthread_join(fibonacciThread, NULL);
    for (int j = 0; j <= seshtrm; j++)
    {
        printf("a[%d] = %d\n", j, n[j]);
    }
    pthread_create(&findingfiboThread, NULL, searchingidxThread, NULL);
    pthread_join(findingfiboThread, NULL);
    free(n);
    return 0;
}