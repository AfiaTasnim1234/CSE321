#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
int N;                  
char fooditem1[200];        
char fooditem2[200];         
pthread_mutex_t lock;  
sem_t bellA;        
sem_t bellB;         
sem_t bellC;         
sem_t thetableisempty;     
void* supplier(void* arg) {
    for (int i = 0; i < N; i++) {
        sem_wait(&thetableisempty);   
        pthread_mutex_lock(&lock);       
        int turningPoint = i % 3;               
        if (turningPoint == 0) {
            sprintf(fooditem1, "Bread");
            sprintf(fooditem2, "Cheese");
            printf("Supplier places: Bread and Cheese\n");
        } else if (turningPoint == 1) {
            sprintf(fooditem1, "Cheese");
            sprintf(fooditem2, "Lettuce");
            printf("Supplier places: Cheese and Lettuce\n");
        } else {
            sprintf(fooditem1, "Bread");
            sprintf(fooditem2, "Lettuce");
            printf("Supplier places: Bread and Lettuce\n");
        }
        pthread_mutex_unlock(&lock);    
        if (turningPoint == 0) sem_post(&bellC);
        else if (turningPoint == 1) sem_post(&bellA);
        else sem_post(&bellB);
    }
    return NULL;
}
void* makerA(void* arg) {
    while (1) {
        sem_wait(&bellA);            
        pthread_mutex_lock(&lock); 
        printf("Maker A picks up %s and %s\n", fooditem1, fooditem2);
        pthread_mutex_unlock(&lock);     
        printf("Maker A is making the sandwich...\n");
        printf("Maker A finished making the sandwich and eats it\n");
        printf("Maker A signals Supplier\n");
        printf("\n");
        sem_post(&thetableisempty);       
    }
    return NULL;
}
void* makerB(void* arg) {
    while (1) {
        sem_wait(&bellB);
        pthread_mutex_lock(&lock);
        printf("Maker B picks up %s and %s\n", fooditem1, fooditem2);
        pthread_mutex_unlock(&lock);
        printf("Maker B is making the sandwich...\n");
        printf("Maker B finished making the sandwich and eats it\n");
        printf("Maker B signals Supplier\n");
        printf("\n");
        sem_post(&thetableisempty);
    }
    return NULL;
}
void* makerC(void* arg) {
    while (1) {
        sem_wait(&bellC);
        pthread_mutex_lock(&lock);
        printf("Maker C picks up %s and %s\n", fooditem1, fooditem2);
        pthread_mutex_unlock(&lock);
        printf("Maker C is making the sandwich...\n");
        printf("Maker C finished making the sandwich and eats it\n");
        printf("Maker C signals Supplier\n");
        printf("\n");
        sem_post(&thetableisempty);
    }
    return NULL;
}
int main() {
    printf("Enter the num :\n");
    scanf("%d", &N);
    pthread_mutex_init(&lock, NULL);    
    sem_init(&bellA, 0, 0);          
    sem_init(&bellB, 0, 0);
    sem_init(&bellC, 0, 0);
    sem_init(&thetableisempty, 0, 1);                                      
    pthread_t tA, tB, tC, tSupplier;
    pthread_create(&tA, NULL, makerA, NULL);        
    pthread_create(&tB, NULL, makerB, NULL);        
    pthread_create(&tC, NULL, makerC, NULL);       
    pthread_create(&tSupplier, NULL, supplier, NULL); 
    pthread_join(tSupplier, NULL);      
    sleep(1);  
    return 0;
}